# TP2 PDS, version OCaml

Ce dépôt contient l'ensemble des fichiers dont vous avez besoin pour travailler
sur le TP2 de PDS, si vous avez choisi de travailler en OCaml. Vous devez le
forker pour pouvoir le modifier : le bouton se situe en haut de l'interface
Gitlab.

**Attention !** Vous devez passer votre fork en *privé*.

La version Java se situe dans un dépôt séparé :
https://gitlab.istic.univ-rennes1.fr/cferry/PDS-TP2-java.git.
